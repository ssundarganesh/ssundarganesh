#!/bin/bash

printf '\n'

printf "This will install pre-requiste apps.\n"

printf '\n'
printf "Deleting old host info files.\n"
rm -f ./fetched/altnix_requ_host_info/host_info*
rm -f  ./fetched/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
sleep 1
printf '\n'

printf "Running ansible-playbook to install pre-requiste installs.\n"
sleep 1
ansible-playbook -i hosts play/host_airtelAfrica_install_pre_requisite.yml

printf "Done, info can be found in: ./fetched/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt \n"

printf '\n'




