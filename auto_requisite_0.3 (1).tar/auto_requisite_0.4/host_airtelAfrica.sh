#!/bin/bash

printf '\n'

printf "This will collect info on: Host Name, IP Address,	NTP status,	python version,	pip3 version,	Curl version,	elinks version,	Telnet path,	netstat version,	snmpd version.\n"

printf '\n'
printf "Deleting old host info files.\n"
rm -f ./fetched/altnix_requ_host_info/host_info*
rm -f  host_info_airtelAfrica.csv
sleep 1
printf "Running ansible-playbook to get Requisite info from target hosts.\n"
sleep 1
ansible-playbook -i hosts play/host_airtelAfrica.yml
printf "Merging collected .txt files to .csv \n"
cp ./templates/host_info_airtelAfrica.csv  ./
for f in ./fetched/altnix_requ_host_info/host_info*.txt; do echo `cat $f` >>  ./host_info_airtelAfrica.csv; done
printf '\n'
printf "Done, info can be found in: host_info_basic.csv \n"

printf '\n'
