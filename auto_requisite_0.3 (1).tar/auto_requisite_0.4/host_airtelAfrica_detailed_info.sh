#!/bin/bash


printf '\n'
printf "Deleting old host info files.\n"
rm -f ./fetched/altnix_requ_host_info/*
sleep 1
printf "Running ansible-playbook to get Requisite info from target hosts.\n"
sleep 1
printf '\n'
ansible-playbook -i hosts play/host_airtelAfrica_detailed.yml
printf "Host details are colledted as separate text files. \n"
printf '\n'
printf "Done, Host text files are in: ./fetched/altnix_requ_host_info/ \n"

printf '\n'
