#!/usr/bin/bash


printf "Elasticsearch Detail of Host: $(uname -n) \n"  >  /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt
printf "===============================================\n" >> /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt

# Create info file in /tmp
touch	/tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt

# Get 
printf "Elasticsearch: \n"  >> /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt
printf "=========\n" >> /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt
uname -n > /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_elastic_info/elastic_info_$(uname -n).txt














