#!/usr/bin/bash


echo `cat /opt/auto_requisite/fetched/requ_host_info/host_info.txt` >>  /opt/auto_requisite/host_info_basic.csv














