#!/bin/bash

uname -n  | tr "\\n" "," > /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
hostname -I | awk '{print $1}'  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#hostnamectl | sed -n 's/Operating System://p'  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#uname -m  | tr "\\n" ","  >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#runlevel  | tr "\\n" ","  >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#cat /proc/cpuinfo |grep "cpu cores" |head -n 1  |awk '{print $4}' | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#grep MemTotal /proc/meminfo | awk '{print $2}' | xargs -I {} echo "scale=4; {}/1024^2" |bc  | xargs printf "%.1f\n"  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
timedatectl |grep NTP   | tr '\n' ' ' | sed -e '$s/$/,/' >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#lsblk -d | awk '/ 8:/' | tr '\n' ' ' | sed -e '$s/$/,/' >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#df -h |awk 'NR!=1 {print}' | grep -v tmpfs |grep -v overlay | tr '\n' ' ' | sed -e '$s/$/,/' >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
#ss -tln  |awk 'NR!=1 {print}' | tr '\n' ' ' | sed -e '$s/$/,/' >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
python3 --version    | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
pip3 --version  |awk '{print $1,$2,$5,$6}'  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
curl --version  |awk 'NR==1 {print}'   |awk '{print $1,$2}'  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
elinks --version   |awk 'NR==1 {print}'  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
which telnet  | tr "\\n" "," >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
netstat --version  |awk 'NR==1 {print}'  | tr "\\n" ","  >> /tmp/altnix_requ_host_info/host_info_$(uname -n).txt
snmpd --version   |awk 'NR==2 {print}'  | tr "\\n" "," >>  /tmp/altnix_requ_host_info/host_info_$(uname -n).txt

echo done



#if [[ -z $(python3 --version) ]];  then ...; fi
#ls | grep . && echo 'files found' || echo 'files not found'



