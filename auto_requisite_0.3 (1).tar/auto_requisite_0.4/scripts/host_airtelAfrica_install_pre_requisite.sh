#!/bin/bash


printf "Pre-requisite install detail of Host: $(uname -n) \n"  > /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "=========================================\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# Create info file in /tmp/altnix_requ_host_info
touch	/tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# Get hostname
printf "Hostname: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "=========\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
uname -n  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# Get local ip
printf "Local ip-address: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "=================\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
ip r   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# Check short OS detail
printf "Short os detail: "  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
cat /etc/redhat-release   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# elinks details
printf "elinks info: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "=============\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
if [[ -z $(elinks --version) ]]
then
	printf "Elinks not found.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	printf "Installing Elinks.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'
    yum install -y elinks  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'
	printf "Just installed elinks, version: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	elinks --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

else
	printf "Elinks already present, the version is: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	elinks --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

fi   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# Telnet
printf "Telnet detail: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "===============\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
if [[ -z $(which telnet) ]]
then
	printf "Telnet not found.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	printf "Installing telnet.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'
    yum install -y telnet telnet-server  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	printf '\n'
	printf "Just installed telnet, the path is: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	which telnet >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

else
	printf "Telnet was already present, the path is: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	which telnet  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

fi   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# net-tools details
printf "net-tools (netstat) info: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "==========================\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
if [[ -z $(netstat --version) ]]
then
	printf "net-tools not found.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	printf "Installing net-tools.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'
    yum install -y net-tools  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'	
	printf "Just installed net-tools, detail: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	netstat --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

else
	printf "net-tools was already present, detail: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	netstat --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

fi   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

# snmpd details
printf "snmpd (netstat) info: \n"  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf "==========================\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
if [[ -z $(snmpd --version) ]]
then
	printf "snmpd not found.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	printf "Installing snmpd.\n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'
    yum install -y snmpd  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
    printf '\n'	
	printf "Just installed snmpd, detail: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	snmpd --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

else
	printf "snmpd was already present, detail: \n" >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
	snmpd --version >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt

fi   >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/pre_requisite_install_$(uname -n).txt



echo done



















