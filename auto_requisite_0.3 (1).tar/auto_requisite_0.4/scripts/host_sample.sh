#!/bin/bash


printf "OS Detail of Host: $(uname -n) \n"  > /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "=========================================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Create info file in /tmp/altnix_requ_host_info
touch	/tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Get hostname
printf "Hostname: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "=========\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
uname -n  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Get local ip
printf "Local ip-address: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "=================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
ip r   >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Get Full os details
# printf "Full OS details: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
# printf "================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
# cat /etc/os-release  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
# printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check short OS detail
printf "Short os detail: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
cat /etc/redhat-release   >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check cpu details
printf "CPU Info: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "=========\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
lscpu  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check memory details
printf "Memory info: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "============\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
free -h  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check disk partion details
printf "Disk partion detail: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "====================\n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
fdisk -l  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check selinux status
#printf "SELinux status: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
sestatus  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "===============\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check firewall status
printf "Firewall status: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
systemctl status firewalld  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check time details
printf "Time date details: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "==================\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
timedatectl   >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt

# Check runlevel
printf "Run-Level: \n"  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf "==========\n" >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
systemctl get-default   >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt
printf '\n%s\n'  >> /tmp/altnix_requ_host_info/os_info_$(uname -n).txt



# if [[ `which yum` ]]; then
	     # printf "ansible not found, installing \"ansible\"."
         # IS_YUM=1
         # sudo yum install epel-release -y
         # sudo yum install ansible -y
         
      # else [[ `which apt` ]]; then
         # printf "ansible not found, installing \"ansible\"."
		 # IS_APT=1
         # sudo apt-add-repository ppa:ansible/ansible -y
         # sudo apt update -y
         # sudo apt install ansible -y
      # sleep 1
      # fi 
















